from flask import Flask, Response, render_template
import cv2
import numpy as np

app = Flask(__name__)

# Load ArUco dictionary and detector parameters
ARUCO_DICT = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
detector = cv2.aruco.ArucoDetector(ARUCO_DICT, cv2.aruco.DetectorParameters())

# Camera Calibration Matrix (Replace with actual calibration values)
camera_matrix = np.array([[800, 0, 320], 
                          [0, 800, 240], 
                          [0, 0, 1]], dtype=np.float32)
dist_coeffs = np.zeros((5, 1), dtype=np.float32)  # Assuming no lens distortion

# Open webcam
cap = cv2.VideoCapture(0)

def generate_frames():
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect ArUco markers
        corners, ids, _ = detector.detectMarkers(gray)

        if ids is not None:
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

            marker_length = 0.05  # Define marker size in meters

            for i in range(len(ids)):
                # Estimate pose
                rvec, tvec, _ = cv2.aruco.estimatePoseSingleMarkers(corners[i], marker_length, camera_matrix, dist_coeffs)
                cv2.drawFrameAxes(frame, camera_matrix, dist_coeffs, rvec, tvec, 0.03)

                # Get top-left corner
                corner = corners[i][0]
                top_left = (int(corner[0][0]), int(corner[0][1]))

                # Display marker ID
                cv2.putText(frame, f"ID: {ids[i][0]}", top_left, cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                # Extract X, Y, Z coordinates
                x, y, z = tvec[0][0]
                cv2.putText(frame, f"X: {x:.2f}m", (top_left[0], top_left[1] + 20), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                cv2.putText(frame, f"Y: {-y:.2f}m", (top_left[0], top_left[1] + 40), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                cv2.putText(frame, f"Z: {z:.2f}m", (top_left[0], top_left[1] + 60), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

        # Convert frame to JPEG
        _, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        # Yield the frame to stream
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)
